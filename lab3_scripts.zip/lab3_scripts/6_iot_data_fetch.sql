/**proceudre iot_data_fetch 
* description: fetches IOT sensor data from IOT SODA web service into log_table iot_raw; parses sensor data into table iot_parsed
* includes commit: yes
* author: Daniel Ivanescu (daniel.ivanescu@oracle.com)
* date: 10.06.2021
* demo call:
begin
  iot_data_Fetch;
end;
*/


create or replace procedure iot_data_fetch
is
  l_clob clob;
  l_batch_id number;
begin

  l_clob := APEX_WEB_SERVICE.MAKE_REST_REQUEST(
    p_url                  => 'https://tn1tv18ynzxubz5-iosp.adb.eu-frankfurt-1.oraclecloudapps.com/ords/sensorapi/soda/latest/iot'
   ,p_http_method          => 'GET'
   ,p_username             => 'sensordata'
   ,p_password             => 'TheSims2IKEA#'
   ); 
insert into iot_raw (json_document) values (l_clob) returning batch_id into l_batch_id;

commit;

insert into iot_parsed (batch_id,id,last_modified,created_on,object_name,tempmc,pres,hum,airq)
SELECT l_batch_id as batch_id
       ,jt.id
       ,jt.last_modified
       ,jt.created_on
       ,jt.object_name
       ,jt.TempMC
       ,jt.Pres
       ,jt.Hum
       ,jt.AirQ
FROM iot_raw,
JSON_TABLE(json_document, '$.items[*]'
COLUMNS (id varchar2(255) PATH '$.id',
         last_modified timestamp PATH '$.lastModified',
         created_on timestamp PATH '$.created',
         object_name varchar2(255) PATH '$.value.objectname',
         TempMC integer PATH '$.value.sensordata[0].sensorvalue',
         Pres integer PATH '$.value.sensordata[1].sensorvalue',
         Hum integer PATH '$.value.sensordata[2].sensorvalue',
         AirQ integer PATH '$.value.sensordata[3].sensorvalue'
         )
         )
AS jt
where iot_raw.batch_id = l_batch_id;


end iot_data_fetch;


