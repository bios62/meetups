/** apex_oml_datamodel script
*used for meetup "From Edge to to Machine Learning" Hands on Lab 3
*contains supporting tables for accessing OML data from Lab 2
*author: Daniel Ivanescu (daniel.ivanescu@oracle.com)
*date: 10.06.2021
*/

-- token table for OML WS access barer tokens
create table auth_tokens
(token_name varchar2(250)
,token_user varchar2(250)
,token_value varchar2(2500)
,token_inserted date default sysdate
,token_expires date default (sysdate+1/24)
);

-- customers table replicating data from SH schema used in LAB 2 to generate OML model
create table customers as
select * from sh.customers;


-- supplementary_demographics table replicating data from SH schema used in LAB 2 to generate OML model
create table supplementary_demographics
as select * from sh.supplementary_demographics;



-- target table for prediction data
create table cust_affinity_prediction
(cust_id number
,affinity_card varchar2(10)
,affinity_card_pred varchar2(10)
,affinity_card_prob number
,affinity_card_action varchar2(20)
,pred_date date default sysdate
);
