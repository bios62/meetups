create or replace package APEX_OML as

/** APEX_OML package specification script
*used for meetup "From Edge to to Machine Learning" Hands on Lab 3
*contains package specification with functions and procedures for using OML data from Lab 2
*author: Daniel Ivanescu (daniel.ivanescu@oracle.com)
*date: 10.06.2021
*/


/**CONFIGURATION VARIABLES - Please edit the values in quotes '';
*/
g_server varchar2(250) := 'https://adb.eu-frankfurt-1.oraclecloud.com';                                       -- 'change to your cloud host from lab 2'
g_tennant varchar2(250) := 'OCID1.TENANCY.OC1..AAAAAAAAFLF2UASR2SHM5AG2YULP4GJY3AOQVWVVBCMVUK52FNDNKPS3BYRA'; -- 'change to your tennant from lab 2'
g_database varchar2(250) := 'OMLMEETUP';                                                                      -- 'change to your database from lab 2' 
g_oml_user varchar2(250) := 'omluser';                                                                        -- 'change to your machine learning username from lab 2' 
g_oml_pwd varchar2(250) := 'OraMeetupOML!21c#';                                                               -- 'change to your machine learning user password from lab 2'
g_oml_model_uri varchar2(250) := 'automl_affinity_pred';                                                      -- 'change to your oml model uri from lab 2'  
/*END CONFIGURATION
*/

--OML WS endpoints
g_auth_url varchar2(2000) := g_server||'/omlusers/tenants/'||g_tennant||'/databases/'||g_database||'/api/oauth2/v1/token';
g_models_url varchar2(2000) := g_server||'/omlmod/v1/models';
g_score_url varchar2(2000) := g_server||'/omlmod/v1/deployment/'||g_oml_model_uri||'/score';
 
 
/**get_oml_token
* description: Get new token from oml oauth2 or reuse active saved token
* returns varchar2 - barer token value
*demo call script:

declare
  l_token varchar2(32000);
begin
  l_token := APEX_OML.get_oml_token;
  dbms_output.put_line ('token: '||l_token);
end;
*/
function get_oml_token
return VARCHAR2;

/** procedure list_oml_models;
* descrption: retrieves and outputs
*demo call script:

begin
  APEX_OML.list_oml_models;
end;

*/
procedure list_oml_models;

/** procedure get_model_score
* description: calls OML model specified in config via rest; returns probability for value 0 and 1
* input pramaters
*    p_body clob - expects clob with JSON format
* output paramteres
*    p_0_probability - returns probability for affinity card value 0
*    p_1_probability - returns probability for affinity card value 1
*demo call script:
declare
 l_body clob;
 l_0_prob varchar2(1000);
 l_1_prob varchar2(1000);
begin

 l_body := '{
	"inputRecords": [
		{
			"AGE":41,
			"BOOKKEEPING_APPLICATION": 1,
			"CUST_GENDER":"M",
			"CUST_MARITAL_STATUS":"NeverM",
			"EDUCATION":"HS-grad",
			"HOME_THEATER_PACKAGE":1,
			"HOUSEHOLD_SIZE":"4",
			"OCCUPATION":"Crafts",
			"YRS_RESIDENCE":6,
			"Y_BOX_GAMES":1
		}
	]
 }';
 APEX_OML.get_model_score
  (p_body => l_body
  ,p_0_probability =>l_0_prob
  ,p_1_probability =>l_1_prob
  );
 dbms_output.put_line ('O probability: '||l_0_prob);
 dbms_output.put_line ('1 probability: '||l_1_prob);
end;
*/
procedure get_model_score
(p_body          in  clob
,p_0_probability out number
,p_1_probability out number
);


/** procedure get_model_prediction
* description: calls OML model specified in config via rest; returns probability for value 0 and 1
* input pramaters
*    p_body clob - expects clob with JSON format
* output paramteres
*    p_0_probability - returns probability for affinity card value 0
*    p_1_probability - returns probability for affinity card value 1
*demo call script:
declare
 l_pred_value varchar2(10);
 l_pred_probability number;
begin
 for r in (SELECT cust.cust_id, cust.cust_first_name||' '||cust.cust_last_name as cust_name, sup.affinity_card
         FROM customers cust
         join supplementary_demographics sup on cust.cust_id = sup.cust_id
         where sup.affinity_card = 0
         order by cust_id
         fetch first 5 rows only)
         loop
          dbms_output.put_line ('****************************');
          dbms_output.put_line ('customer: '||r.cust_id ||' -  '|| r.cust_name); 
          APEX_OML.get_model_prediction
            (p_cust_id          => r.cust_id
            ,p_pred_value       => l_pred_value
            ,p_pred_probability => l_pred_probability
            );
         dbms_output.put_line ('predicted value: '||l_pred_value ||' probability: '|| l_pred_probability);
         end loop;
end;         
*/

/** procedure function get_cust_body_json
* description: returns json payload for customer data for calling OML via REST service from lab 2
* input pramaters
*    p_cust_id - expects customer id value from customers.cust_id
* return
*  clob with json payload.
*demo call script:
declare 
  l_body clob;
begin
  l_body := apex_oml.get_cust_body_json (p_cust_id => 1);
  dbms_output.put_line ('json payload: '||body);
end;
*/
function get_cust_body_json
(p_cust_id          in number)
return clob;


/** procedure get_model_prediction
* description: calls OML model specified in config via rest for a given customer id; returns predicted value and prediction probability
* input pramaters
*    p_cust_id - expects customer id value from customers.cust_id
* output paramteres
*    p_pred_value- returns predicted value with highest probability
*    p_pred_probability- returns probability for predicted value
*demo call script:
declare
 l_pred_value varchar2(10);
 l_pred_probability number;
begin
 for r in (SELECT cust.cust_id, cust.cust_first_name||' '||cust.cust_last_name as cust_name, sup.affinity_card
         FROM customers cust
         join supplementary_demographics sup on cust.cust_id = sup.cust_id
         where sup.affinity_card = 0
         order by cust_id
         fetch first 5 rows only)
         loop
          dbms_output.put_line ('****************************');
          dbms_output.put_line ('customer: '||r.cust_id ||' -  '|| r.cust_name); 
          APEX_OML.get_model_prediction
            (p_cust_id          => r.cust_id
            ,p_pred_value       => l_pred_value
            ,p_pred_probability => l_pred_probability
            );
         dbms_output.put_line ('predicted value: '||l_pred_value ||' probability: '|| l_pred_probability);
         end loop;
end;         
*/
procedure get_model_prediction
(p_cust_id          in number
,p_pred_value       out varchar2
,p_pred_probability out number
);


/** procedure save_affinity_prediction
* description: calls OML model via rest service, saves prediction data in table cust_affinity_prediction
* input pramaters
*    p_cust_id - expects customer id value from customers.cust_id
*demo call script:
-- single customer
begin 
  APEX_OML.save_affinity_prediction
    (p_cust_id    =>1 );
end;

--batch of customers
begin
 for r in (
         SELECT cust.cust_id, cust.cust_first_name||' '||cust.cust_last_name as cust_name, sup.affinity_card
         FROM sh.customers cust
         join sh.supplementary_demographics sup on cust.cust_id = sup.cust_id
         where sup.affinity_card = 0
         order by cust_id
         fetch first 50 rows only
         )loop
           APEX_OML.save_affinity_prediction
             (p_cust_id    => r.cust_id);
         end loop;
end;
*/
procedure save_affinity_prediction
(p_cust_id          in number
);
end;
